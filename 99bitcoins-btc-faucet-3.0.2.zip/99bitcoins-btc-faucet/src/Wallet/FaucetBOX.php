<?php

class The99Bitcoins_BtcFaucet_Wallet_FaucetBOX implements The99Bitcoins_BtcFaucet_Wallet_WalletInterface
{
    public $limit = 5;

    public $fee = 0;

    public $min = 1;

    protected $apiKey = '';

    public $errorData = null;

    /** @var The99BtcFaucetBOX */
    protected $client = null;

    /**
     * @inheritDoc
     */
    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    /**
     * @return The99BtcFaucetBOX
     */
    protected function client()
    {
        if (!$this->client) {
            $this->client = new The99BtcFaucetBOX($this->apiKey);
        }
        return $this->client;
    }

    /**
     * @inheritDoc
     */
    public function isAccessible()
    {
        if (!$this->apiKey) {
            return false;
        }

        try {
            $data = $this->client()->getBalance();
        } catch (Exception $exception) {
            $data = array(
                'status' => 500,
            );
        }
        return !empty($data['status']) && $data['status'] == 200;
    }

    /**
     * @inheritDoc
     */
    public function getBalance()
    {
        try {
            $data = $this->client()->getBalance();
        } catch (Exception $data) {
            $data = array(
                'status' => 500,
            );
        }
        if (!empty($data['status']) && $data['status'] == 200) {
            return $data['balance'];
        }
        return 0;
    }

    /**
     * @inheritDoc
     */
    public function validateAddress($address)
    {
        $return = !!$address;
        return $return;
    }

    /**
     * @inheritDoc
     */
    public function purchase(array $set)
    {
        $this->errorData = null;
        $return = array();

        foreach ($set as $address => $satoshi) {
            try {
                $data = $this->client()->send($address, $satoshi);
                if (!empty($data['success'])) {
                    $return[$address] = 'faucetbox';
                } else {
                    if (!$this->errorData) {
                        $this->errorData = $data;
                    }
                    $return[$address] = '';
                }
            } catch (Exception $exception) {
                if (!$this->errorData) {
                    $this->errorData = $exception;
                }
            }
        }
        return $return;
    }
}
