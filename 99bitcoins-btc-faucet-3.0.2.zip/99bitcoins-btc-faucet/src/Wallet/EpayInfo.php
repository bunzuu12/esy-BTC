<?php

class The99Bitcoins_BtcFaucet_Wallet_EpayInfo implements The99Bitcoins_BtcFaucet_Wallet_WalletInterface
{
    public $limit = 5;

    public $fee = 0;

    public $min = 1;

    protected $apiKey = '';

    public $errorData = null;

    /** @var The99BtcEpayInfo */
    protected $client = null;

    /**
     * @inheritDoc
     */
    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    /**
     * @return The99BtcEpayInfo
     */
    protected function client()
    {
        if (!$this->client) {
            $this->client = new The99BtcEpayInfo($this->apiKey);
        }
        return $this->client;
    }

    /**
     * @inheritDoc
     */
    public function isAccessible()
    {
        if (!$this->apiKey) {
            return false;
        }

        try {
            $data = is_int($this->client()->getBalance());
        } catch (Exception $exception) {
            $data = false;
        }
        return $data;
    }

    /**
     * @inheritDoc
     */
    public function getBalance()
    {
        try {
            $data = $this->client()->getBalance();
            if (!is_int($data)) {
                $data = 0;
            }
        } catch (Exception $exception) {
            $data = 0;
        }
        return $data;
    }

    /**
     * @inheritDoc
     */
    public function validateAddress($address)
    {
        $return = !!$address;
        return $return;
    }

    /**
     * @inheritDoc
     */
    public function purchase(array $set)
    {
        $this->errorData = null;
        $return = array();

        foreach ($set as $address => $satoshi) {
            try {
                $data = $this->client()->send($address, $satoshi);
                if (!empty($data['status']) && $data['status'] > 0) {
                    $return[$address] = 'epay.info';
                } else {
                    if (!$this->errorData) {
                        $this->errorData = $data;
                    }
                    $return[$address] = '';
                }
            } catch (Exception $exception) {
                if (!$this->errorData) {
                    $this->errorData = $exception;
                }
            }
        }
        return $return;
    }
}
