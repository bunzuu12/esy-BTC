<?php

class The99Bitcoins_BtcFaucet_Wallet_Bitcoind implements The99Bitcoins_BtcFaucet_Wallet_WalletInterface
{
    public $limit = 250;

    public $fee = 0.05;

    public $min = 10000;

    protected $url = '';

    protected $secret = '';

    public $errorData = null;

    /** @var The99Bitcoins_BtcFaucet_Client_BitCoinCore */
    protected $client = null;

    protected $supports = array();

    protected $currency = 'BTC';

    protected $currencies = array('BTC');

    /**
     * @inheritDoc
     */
    public function __construct($config, $currency = 'BTC')
    {
        $this->url = $config['url'];
        $this->secret = $config['secret'];
        $this->supports = $config['supports'];
        $this->currency = $currency;
    }

    /**
     * @return The99Bitcoins_BtcFaucet_Client_BitCoinCore
     */
    protected function client()
    {
        if (!$this->client) {
            $this->client = new The99Bitcoins_BtcFaucet_Client_BitCoinCore($this->url);
        }
        return $this->client;
    }

    /**
     * @inheritDoc
     */
    public function isAccessible()
    {
        if (!in_array($this->currency, $this->currencies)) {
            return false;
        }
        if (!$this->url) {
            return false;
        }

        $return = true;
        try {
            $this->client()->getinfo();
            if ($this->secret) {
                $this->client()->walletpassphrase($this->secret, 1);
            }
            foreach ($this->client()->listaccounts() as $k => $v) {
                if ($k == '') {
                    continue;
                }
                if (!$v) {
                    continue;
                }
                if ($v > 0) {
                    $this->client()->move($k, '', $v);
                } else {
                    $this->client()->move('', $k, -$v);
                }
            }
        } catch (Exception $exception) {
            $return = false;
        }
        return $return;
    }

    /**
     * @inheritDoc
     */
    public function getBalance()
    {
        try {
            $return = $this->client()->getbalance('', 0) * 100000000;
        } catch (Exception $exception) {
            $return = 0;
        }
        return $return;
    }

    /**
     * @inheritDoc
     */
    public function validateAddress($address)
    {
        try {
            $validation = $this->client()->validateaddress($address);
            $return = !empty($validation['isvalid']);
        } catch (Exception $exception) {
            $return = false;
        }
        return $return;
    }

    /**
     * @inheritDoc
     */
    public function purchase(array $set)
    {
        $this->errorData = null;
        $return = array();

        foreach ($set as $address => $satishi) {
            $set[$address] = $satishi / 100000000;
        }
        try {
            if ($this->secret) {
                $this->client()->walletpassphrase($this->secret, 10);
            }
            $transactionId = $this->client()->sendmany('', $set, 0);
            foreach ($set as $address => $_) {
                $return[$address] = $transactionId;
            }
        } catch (Exception $exception) {
            if (!$this->errorData) {
                $this->errorData = $exception;
            }
        }
        return $return;
    }
}
