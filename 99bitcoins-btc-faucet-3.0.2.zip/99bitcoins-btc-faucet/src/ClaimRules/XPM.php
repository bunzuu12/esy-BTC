<?php

class The99Bitcoins_BtcFaucet_ClaimRules_XPM extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'XPM';
}
