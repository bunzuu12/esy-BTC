<?php

class The99Bitcoins_BtcFaucet_ClaimRules_USDETH extends The99Bitcoins_BtcFaucet_ClaimRules_BaseExchangeRate
{
    const currency = 'ETH';
}
