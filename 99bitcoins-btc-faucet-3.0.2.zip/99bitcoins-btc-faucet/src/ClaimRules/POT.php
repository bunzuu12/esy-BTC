<?php

class The99Bitcoins_BtcFaucet_ClaimRules_POT extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'POT';
}
