<?php

class The99Bitcoins_BtcFaucet_ClaimRules_BTX extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'BTX';
}
