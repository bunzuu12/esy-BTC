<?php

class The99Bitcoins_BtcFaucet_ClaimRules_DOGE extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'DOGE';
}
