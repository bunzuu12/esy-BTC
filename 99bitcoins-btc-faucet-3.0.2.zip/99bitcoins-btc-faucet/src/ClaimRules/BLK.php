<?php

class The99Bitcoins_BtcFaucet_ClaimRules_BLK extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'BLK';
}
