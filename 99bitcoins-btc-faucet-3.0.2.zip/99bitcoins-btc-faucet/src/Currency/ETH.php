<?php

class The99Bitcoins_BtcFaucet_Currency_ETH
{
    public $symbol = 'ETH';
    public $name = 'Ethereum';
    public $satoshi = 'Ethereum Satoshi';
    public $size = 100000000;

    public static function validateAddress($address)
    {
        if (!preg_match('/^0x[a-fA-F0-9]{40}$/', $address)) {
            return false;
        }
        if (!in_array('sha3', hash_algos())) {
            return true;
        }

        $address = str_replace('0x', '', $address);
        $addressHash = hash('sha3', strtolower($address));
        $addressArray = str_split($address);
        $addressHashArray = str_split($addressHash);

        for ($i = 0; $i < 40; $i++) {
            // the nth letter should be uppercase if the nth digit of casemap is 1
            if ((intval($addressHashArray[$i], 16) > 7 && strtoupper($addressArray[$i]) !== $addressArray[$i]) || (intval($addressHashArray[$i], 16) <= 7 && strtolower($addressArray[$i]) !== $addressArray[$i])) {
                return false;
            }
        }
        return true;
    }
}
