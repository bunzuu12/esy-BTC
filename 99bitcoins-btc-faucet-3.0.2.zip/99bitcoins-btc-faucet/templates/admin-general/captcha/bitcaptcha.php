<?php
/**
 * @var The99Bitcoins_BtcFaucet_Plugin $this
 * @var array $config
 * @var array $claim_rules
 * @var array $seniority_rules
 *
 * @var string $notice_message
 * @var string $notice_css_class
 */
?>
<h4>
    <input type="radio" name="config[captcha]" value="bitcaptcha" id="config[captcha][bitcaptcha]"<?php if (!empty($config['captcha']) && $config['captcha'] == 'bitcaptcha'): ?> checked="checked"<?php endif ?>> <a href="http://bitcaptcha.io/" target="_blank"><?= esc_html__('BitCaptcha', '99btc-bf') ?></a><br>
    <input type="checkbox" name="config[captchas][]" value="bitcaptcha" id="config[captchas][bitcaptcha]" style="position: relative; top: 2px"<?php if (!empty($config['captchas']) && in_array('bitcaptcha', $config['captchas'])): ?> checked="checked"<?php endif ?>> <label for="config[captchas][bitcaptcha]"><small><?= esc_html__('Allow as an option', '99btc-bf') ?></small></label><br>
</h4>
<table class="form-table">
    <tr>
        <th scope="row">
            <label for="config[bitcaptcha_site_id]"><?= esc_html__('SiteID', '99btc-bf') ?></label>
        </th>
        <td>
            <input class="regular-text" type="text" name="config[bitcaptcha_site_id]" id="config[bitcaptcha_site_id]" value="<?= esc_attr(empty($config['bitcaptcha_site_id']) ? '' : $config['bitcaptcha_site_id']) ?>" placeholder="<?= esc_html__('SiteID', '99btc-bf') ?>">
        </td>
    </tr>
    <tr>
        <th scope="row">
            <label for="config[bitcaptcha_site_key]"><?= esc_html__('Site Key', '99btc-bf') ?></label>
        </th>
        <td>
            <input class="regular-text" type="text" name="config[bitcaptcha_site_key]" id="config[bitcaptcha_site_key]" value="<?= esc_attr(empty($config['bitcaptcha_site_key']) ? '' : $config['bitcaptcha_site_key']) ?>" placeholder="<?= esc_html__('Site Key', '99btc-bf') ?>">
        </td>
    </tr>
    <tr>
        <th scope="row">
            <label for="config[bitcaptcha_mode]"><?= esc_html__('Captcha Mode', '99btc-bf') ?></label>
        </th>
        <td>
            <select name="config[bitcaptcha_mode]" id="config[bitcaptcha_mode]">
                <option value=""<?= selected(empty($config['bitcaptcha_mode'])) ?>><?= esc_html__('Mode #1：Visible Button', '99btc-bf') ?></option>
                <option value="invisible"<?= selected(!empty($config['bitcaptcha_mode']) && $config['bitcaptcha_mode'] == 'invisible') ?>><?= esc_html__('Mode #2：Invisible Captcha', '99btc-bf') ?></option>
            </select>
        </td>
    </tr>
    <tr>
        <th scope="row">
            <label for="config[bitcaptcha_type]"><?= esc_html__('Load type', '99btc-bf') ?></label>
        </th>
        <td>
            <select name="config[bitcaptcha_type]" id="config[bitcaptcha_type]">
                <option value=""<?= selected(empty($config['bitcaptcha_type'])) ?>><?= esc_html__('Regular', '99btc-bf') ?></option>
                <option value="lazy"<?= selected(!empty($config['bitcaptcha_type']) && $config['bitcaptcha_type'] == 'lazy') ?>><?= esc_html__('Lazy', '99btc-bf') ?></option>
            </select>
        </td>
    </tr>
</table>
