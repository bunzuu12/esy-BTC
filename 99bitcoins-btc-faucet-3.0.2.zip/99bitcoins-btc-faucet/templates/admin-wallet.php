<?php
/**
 * @var The99Bitcoins_BtcFaucet_Plugin $this
 *
 * @var string $notice_message
 * @var string $notice_css_class
 *
 * @var string $show
 * @var string $bitcoind_status
 * @var string $faucethubio_status
 * @var string $epayinfo_status
 */
?>
<div class="wrap the99btcwallets">
    <h1><?= esc_html__('Wallet', '99btc-bf') ?><?php if (!empty($this->node['video-tutorial'])): ?> [<a href="#video-tutorial" data-tutorial="<?= esc_attr($this->node['video-tutorial']) ?>" style="text-decoration: underline"><?= esc_html__('Video tutorial') ?></a>]<?php endif ?></h1>

    <?php if (!empty($this->node['video-tutorial'])): ?>
        <script src="//fast.wistia.com/embed/medias/<?= esc_attr($this->node['video-tutorial']) ?>.jsonp" async></script>
        <script src="//fast.wistia.com/assets/external/E-v1.js" async></script>
        <div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;display: none" data-tutorial="<?= esc_attr($this->node['video-tutorial']) ?>">
            <div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;">
                <div class="wistia_embed wistia_async_<?= esc_attr($this->node['video-tutorial']) ?> videoFoam=true" style="height:100%;width:100%">&nbsp;</div>
            </div>
        </div>
    <?php endif ?>

    <?php if (!empty($notice_message)): ?>
        <div class="<?= $notice_css_class ?>">
            <p><?= $notice_message ?></p>
        </div>
    <?php endif ?>

    <div><?= esc_html__('To understand current state please check Status field above.', '99btc-bf') ?></div>
    <div><?= esc_html__('Not configured - means wallet was not configured and nothing will be paid.', '99btc-bf') ?></div>
    <div><?= esc_html__('Unreachable - means wallet was configured but we can not reach it, usually it means you need to check data and save it one more time.', '99btc-bf') ?></div>
    <div><?= esc_html__('Active - everything is good, addresses will be paid if you have enough balance.', '99btc-bf') ?></div>

    <h2 class="nav-tab-wrapper the99btcwallets">
        <a href="#" class="nav-tab<?php if (!$show || $show == 'FaucetHub'): ?> nav-tab-active<?php endif ?>" data-layer="FaucetHub"><?= esc_html__('faucethub.io', '99btc-bf') ?></a>
        <a href="#" class="nav-tab<?php if ($show == 'Bitcoind'): ?> nav-tab-active<?php endif ?>" data-layer="Bitcoind"><?= esc_html__('Bitcoind JSON-RPC', '99btc-bf') ?></a>
    </h2>

    <?php include __DIR__ . '/admin-wallet/bitcoind.php' ?>
    <?php include __DIR__ . '/admin-wallet/faucethub-io.php' ?>

</div>
