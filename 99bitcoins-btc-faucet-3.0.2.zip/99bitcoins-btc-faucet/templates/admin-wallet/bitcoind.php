<?php
/**
 * @var string $bitcoind_status
 * @var array $wallet
 */
?>
<form method="post" novalidate="novalidate" id="Bitcoind" style="display: none">
    <table class="form-table">
        <tr>
            <th scope="row">
                <?= esc_html__('Status', '99btc-bf') ?>
            </th>
            <td>
                <?= esc_html($bitcoind_status) ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="wallet[Bitcoind][url]"><?= esc_html__('Wallet url', '99btc-bf') ?></label>
            </th>
            <td>
                <input class="regular-text" type="text" name="wallet[Bitcoind][url]" id="wallet[Bitcoind][url]" value="<?= esc_attr($wallet['Bitcoind']['url']) ?>" placeholder="<?= esc_attr__('http://user:password@host:port', '99btc-bf') ?>" autocomplete="off">
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="wallet[Bitcoind][secret]"><?= esc_html__('Wallet passphrase', '99btc-bf') ?></label><br>
                <small><?= esc_html__('if it was set', '99btc-bf') ?></small>
            </th>
            <td>
                <input class="regular-text" type="text" name="wallet[Bitcoind][secret]" id="wallet[Bitcoind][secret]" value="<?= esc_attr($wallet['Bitcoind']['secret']) ?>" placeholder="<?= esc_attr__('Passphrase', '99btc-bf') ?>" autocomplete="off">
            </td>
        </tr>
    </table>
    <?php submit_button(); ?>
    <p>
        <small><a href="https://en.bitcoin.it/wiki/API_reference_(JSON-RPC)" target="_blank" rel="nofollow"><?= esc_html__('API reference (JSON-RPC)', '99btc-bf') ?></a></small><br>
        <small><a href="https://en.bitcoin.it/wiki/Original_Bitcoin_client/API_calls_list" target="_blank" rel="nofollow"><?= esc_html__('Original Bitcoin client/API calls list', '99btc-bf') ?></a></small><br>
    </p>
</form>
