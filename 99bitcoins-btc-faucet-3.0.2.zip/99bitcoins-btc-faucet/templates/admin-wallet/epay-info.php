<?php
/**
 * @var string $epayinfo_status
 * @var array $config
 */
?>
<form method="post" novalidate="novalidate" id="epay-info" style="display: none">
    <p style="color: red"><?= esc_html__('Support of epay.info will be removed in future version, please avoid its usage.', '99btc-bf') ?></p>
    <table class="form-table">
        <tr>
            <th scope="row">
                <?= esc_html__('Status', '99btc-bf') ?>
            </th>
            <td>
                <?= esc_html($epayinfo_status) ?>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="config[epayinfo_api_key]"><?= esc_html__('API key', '99btc-bf') ?></label>
            </th>
            <td>
                <input class="regular-text" type="text" name="config[epayinfo_api_key]" id="config[epayinfo_api_key]" value="<?= esc_attr($config['epayinfo_api_key']) ?>" placeholder="<?= esc_attr__('API key', '99btc-bf') ?>" autocomplete="off" disabled="disabled">
            </td>
        </tr>
    </table>
    <?php submit_button(null, 'primary', 'submit', true, array('disabled' => 'disabled')); ?>
    <p>
        <small><a href="https://epay.info/MyFaucet/" target="_blank" rel="nofollow"><?= esc_html__('epay.info PHP library', '99btc-bf') ?></a></small><br>
    </p>
</form>
