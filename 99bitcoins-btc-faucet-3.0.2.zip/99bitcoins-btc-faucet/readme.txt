=== Bitcoin faucet ===
Contributors: michael.gusev@olovei.com
Tags: btc, bitcoin, faucet, blockchain-wallet
Requires at least: 4.0.1
Tested up to: 4.9.4
Stable tag: 4.9.4
License: MIT

Bitcoin faucet by 99bitcoins.com.

== Description ==

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/99bitcoins-btc-faucet` directory, or install the plugin through the WordPress plugins screen directly
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the "Bitcoin Faucet" screen to configure the plugin

== Screenshots ==

1. Configuration page
2. Tooltips specification
3. Calculator in action

== Changelog ==

= 3.0.2 =
Removal of support fee

= 3.0.1 =
Removal of 1 second delay on every request

= 3.0.0 =
Added support of multiple faucets
Added support of multiple captcha
Added support of rain captcha
Added support of Bitcoin Cash
Added support of Bitcore
Added support of Blackcoin
Added support of Peercoin
Added support of Primecoin
Added support of Potcoin
Fixed support of Ethereum

= 2.5.0 =
Added support of Dogecoin
Added support of SegWit LTC addresses

= 2.4.6 =
Better payout process in case if address isn't correct or isn't linked with payment wallet

= 2.4.5 =
Fixed issue when stats have dates with 0 claims

= 2.4.4 =
Fix when $wpdb->srtm isn't accessible
Separate cache for stats of claims

= 2.4.3 =
Fix of reset data feature

= 2.4.2 =
Fix of issue when payout isn't scheduled in case when users have to link their addresses

= 2.4.1 =
Better error reporting in case of Faucethub API request limitation

= 2.4.0 =
New logic of payout generation
New logic of payout queue

= 2.3.1 =
Fix of javascript error in case when users are required to link their addresses

= 2.3.0 =
ETH support
Bitcaptcha support
Dispaying number of referred address
Extra ad on claim
Sticky Address

= 2.2.1 =
Fixing issue when email of user without claims shows all addresses and ips
Native DB locking system while payout

= 2.2.0 =
Plugin was renamed to Crypto Faucet
Added support of ETH
Admin can edit users' addresses
Better error reporting while updating profile's addresses
Better error reporting while payout process

= 2.1.4 =
Fixing calculation of 24/h claims when user isn't logged in

= 2.1.3 =
Fixing calculation of 24/h claims when both users and guests are allowed to claim

= 2.1.2 =
Fixed issue with fake buttons feature

= 2.1.1 =
Payouts to valid addresses will be rescheduled automatically
On payout Bitcoind Wallet spends unconfirmed balance

= 2.1.0 =
Added support of coin-hive.com captcha

= 2.0.1 =
Payout improvements for faucethub to don't break their security rules
Added option to specify explicit usage of cloudflare
Fixed issue with currencies configuration page

= 2.0.0 =
Make payout will send email if it took more than 1 minute to schedule it
Make payout was optimized to work faster
In general setting there's option to set auto-payout
Support of IPv6
Better support of CloudFlare
Disabling faucet while upgrade
Support of DASH and LTC

= 1.7.6 =
Improvements for bitcoind support
Claims page in admin shows how much BTC needs to be loaded to wallet to cover payout
Claims page in admin shows fee calculator in case of bitcoind usage
epay.info became depricated and will be removed in future version

= 1.7.5 =
Storing ref address in cookies so people can pass registration without loozing ref

= 1.7.4 =
Configuration option to specify how to load captcha: regular, ajax and lazy
Fixing issue with chart render
Updating stats requests to send data to domain insteaad of ip address

= 1.7.3 =
New support address

= 1.7.2 =
Fixing db prefix

= 1.7.1 =
Fixing submit count on Claims page

= 1.7.0 =
* Adding different claim rules
* Adding update notification even plugin support was disabled
* Adding links to captcha providers
* Adding no captcha option
* Adding better randomizer of claimed prize
* Adding video tutorials
* Adding reinstallation of cron schedule
* Support email has been changed
* Removing faucetbox support
* Minor improvements

= 1.6.2 =
* Fixing issue with epay balance

= 1.6.1 =
* Improving payment log messages

= 1.6.0 =
* Adding real bitcoin address validator
* Adding warning message when "Make payout" button was clicked
* Adding option to set manually threshold for an address
* Adding recaptcha support
* Handling more errors from epay side

= 1.5.5 =
* Adding "Clear scheduled payout" button in claims page
* Disabling "Make payment" button on claims page in case if we have scheduled transactions
* Rescheduling payment for an address in case of network failure (epay.info issue)

= 1.5.4 =
* Displaying error also in case when payment api failed on their side

= 1.5.3 =
* Adding extra debug information while payout for better issue understanding

= 1.5.2 =
* Allowing to schedule payment even wallet wasn't configured
* Better fee calculation

= 1.5.1 =
* Lazy load of solvemedia captcha

= 1.5.0 =
* Cron run adds stamps to avoid double payment
* Disabling "Make Payment" button when it was clicked to avoid double payment
* Side menu items were reduced
* Adding support fee
* Adding option to opt out of plugin support

= 1.4.8 =
* Payments navigation points to Payouts instead of Claims

= 1.4.7 =
* Moving Claims after Payouts in navigation

= 1.4.6 =
* Adding navigation to "How to use" page

= 1.4.5 =
* Adding onscreen navigation

= 1.4.4 =
* Fixing missed message in support request
* Adding admin email to support request
* Handling error when usage of WP_Http_Curl returns WP_Error
* New short code [btc-faucet-total-paid] to display paid amount of Satoshi "NNN Satoshi"

= 1.4.3 =
* Displaying API keys on wallet page

= 1.4.2 =
* Disabling possibility to be refer of yourself

= 1.4.1 =
* Improving error message

= 1.4.0 =
* Possibility to set translations for frontend part
* Renaming "Send diagnostic" to "Support"
* Fixing issue when plugins page displays inforrect information about this plugin

= 1.3.11 =
* Fixing issue with payment failure when using faucethub.io

= 1.3.10 =
* Adding faucethub.io support
* No way to set epay.info api key if SoapClient extension isn't installed
* Adding reset option to "tools" page
* Adding "check information" page where you can find related addresses and users
* Adding phpinfo to "send diagnostic"

= 1.3.9 =
* Fixing chart on check page

= 1.3.8 =
* Updating chart library to 2.4.0
* Loading admin scripts and styles only on the plugin pages to avoid conflicts with other plugins

= 1.3.7 =
* Adding more detailed payout log
* Log size will contain 100 last records
* Avoind repeat of "No scheduled payouts were found" message in log
* Adding limitation of payout per 1 run cron circle - 5 addresses for FaucetBOX and EpayInfo, 250 addresses for Bitcoind

= 1.3.6 =
* Fixing "looks like we got no XML document" epay.info error while payout

= 1.3.5 =
* Adding autoupdate feature

= 1.3.4 =
* Displaying information about payout runs
* Fixing issues with epay.info when not enough balance for payout

= 1.3.3 =
* improving db query in case when only linked addresses should be paid

= 1.3.2 =
* fixing calcualtion of claims on edit profile page

= 1.3.1 =
* adding information about seniority and submits limitation to user's profile
* hidding submits information on check address page when users' registration is required
* hidding seniority information on check address page when users' seniority is enabled

= 1.3.0 =
* extending claim section to show more information about payouts
* daily claim limitation is based also on user if registration is required
* added option "Force users to specify one Bitcoin address" if registration is required
* added option "Pay only to addresses linked to accounts" if registration is required
* added option "Seniority is based on user instead of address" if registration is required

= 1.2.7 =
* adding payout tracker
* adding epay.info support
* adding link to check address page from claim log
* adding link to check address page from payout log
* fixing ajax history loader

= 1.2.6 =
* hidding ref information if ref bonus was not set
* improving diagnostic tool to work with proper temp directory
* removing site url from faucet urls (requires resave of general settings)
* adding bonus and penalty options on tools page

= 1.2.5 =
* adding right version suffix to assets

= 1.2.4 =
* adding timer and sound signal
* adding prefixes for libraries to avoid conflicts
* adding initialization between updates

= 1.2.3 =
* fixing double opera turbo setting
* fixing payout amount to be displayed correctly
* fixing faucetbox link on payout page
* add new section to send diagnostic information

= 1.2.2 =
* allowing to use several tabs with fake buttons

= 1.2.1 =
* Added tracker
* Added counter of submits

= 1.2.0 =
* Added option to enable fake buttons
* Added option to allow only registered users

= 1.1.5 =
* Fixing 1000 issue
* Fixing set_time_limit issue
* Adding help text to admin panel

= 1.1.4 =
* Fixing __sort issue on stat page

= 1.1.3 =
* Fixing ?page=N with check address form
* Fixing faucetbox url in transaction history

= 1.1.2 =
* Fixing generation of urls when ?page=N is used

= 1.1.0 =
* Replacing short declarations with full

= 1.0.0 =
* Implementation
