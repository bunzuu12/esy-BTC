<?php

class The99BtcEpayInfo
{
    protected $api_key = '';
    public $last_status = null;
    protected $api_wsdl = "http://api.epay.info/?wsdl";

    public function __construct($api_key) {
        $this->api_key = $api_key;
    }

    public function send($to, $amount, $referral = false) {
        if (class_exists('SoapClient')) {
            $client = new SoapClient($this->api_wsdl);
            return $client->send($this->api_key, $to, $amount, $referral ? 1 : 2);
        }
        return false;
    }

    public function getBalance() {
        if (class_exists('SoapClient')) {
            $client = new SoapClient($this->api_wsdl);
            return $client->f_balance($this->api_key, 1);
        }
        return false;
    }
}
